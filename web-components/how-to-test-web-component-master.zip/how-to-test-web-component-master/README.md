# How To Test a Web Component

This is a repository containing a project demonstrating how to test Web Components.

# Related Article

You can read the related article on [Medium](https://medium.com/@unrealprogrammer/how-to-test-a-web-component-b5d64d5e8bb0) and on [UNREALprogrammer](https://www.unrealprogrammer.com/how-to-test-a-web-component/).
